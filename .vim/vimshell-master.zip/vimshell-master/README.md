# VimShell

For information, check doc/vimshell.txt.
